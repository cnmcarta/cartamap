    <div id="carta-map-point">

    <label class="map_location_label">Address:</label><input class="map_location_input"  name="map_location_address" value="<?php echo $map_location_address; ?>" /><br>	
    <label class="map_location_label">City:</label><input class="map_location_input"  name="map_location_city" value="<?php echo $map_location_city; ?>" /><br>	
    <label class="map_location_label">State:</label><input class="map_location_input"  name="map_location_state" value="<?php echo $map_location_state; ?>" /><br>	
    <label class="map_location_label">Zipcode:</label><input class="map_location_input"  name="map_location_zipcode" value="<?php echo $map_location_zipcode; ?>" /><br>	
	<hr>
	<!-- Latitude and Longitude should be calculated by Google<br> -->
    <label class="map_location_label">Latitude:</label><input class="map_location_input"  name="map_location_lat" value="<?php echo $map_location_lat; ?>" /><br>
    <label class="map_location_label">Longitude:</label><input class="map_location_input"  name="map_location_lng" value="<?php echo $map_location_lng; ?>" /><br>
	
	</div>